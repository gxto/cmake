// hello.h中的内容

#ifndef __hello_
#define __hello_

void hello(void);

#endif
