
// hello.c中的内容

#include "hello.h"

void hello(void)
{
  printf("hello world !\n");
}

