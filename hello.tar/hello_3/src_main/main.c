// main.c中的内容

#include <stdio.h>
#include <stdlib.h>
#include "../lib_hello/hello.h"

int main(void)
{
  hello();
  return 0;
}


