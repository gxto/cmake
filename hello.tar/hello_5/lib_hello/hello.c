// hello.c 内容

#include "hello.h"
void HelloFunc()
{
  printf("Hello World !\n");
}
