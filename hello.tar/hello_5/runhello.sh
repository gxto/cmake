# 工程最外层目录的shell文件，用于调用可执行文件
hello
