#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "../lib_hello/hello.h"


int main()
{
  HelloFunc();
  return 0;
}
